
#include <stdio.h>  
#include <stdlib.h>  

int main(int argc, char** argv)
{
  
  FILE *fileptr;
  char *buffer;
  long filelen;
  FILE *fp;
  long i;
  unsigned short tempPixel;
   
  if(argc < 3)
  {
    puts("Missing params");
    exit(1);
  }
  

   
  fileptr = fopen(argv[1], "rb");  // Open the file in binary mode
  fp = fopen( argv[2] , "wb" );
  fseek(fileptr, 0, SEEK_END);          // Jump to the end of the file
  filelen = ftell(fileptr);             // Get the current byte offset in the file
  rewind(fileptr);                      // Jump back to the beginning of the file

  buffer = (char *)malloc((filelen+1)*sizeof(char)); // Enough memory for file + \0
  fread(buffer, filelen, 1, fileptr); // Read in the entire file
  
  for(i = 0; i < filelen; i += 4)
  {
    unsigned char s =(buffer[i+1] << 8 );
    unsigned char j =(buffer[i] & 0xff);
    tempPixel = (buffer[i+1] << 8 ) | (buffer[i] & 0xff);
    tempPixel = tempPixel / 4;
    fwrite(&tempPixel , 1 , sizeof(buffer[i]) , fp );
  }
  fclose(fileptr); // Close the file
  fclose(fp);
  
  return 0;
}