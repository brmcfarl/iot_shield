#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termio.h>
#include <signal.h>

void allwrite(int fd, unsigned char *buf, int len);

int main(int argc, char *argv[]) 
{
  //file descriptors and amount read/wrote
  int fdwrite, rcwrite;
  int fdread, rcread;
  int fdwrite_32, rcwrite_32;
  int fdread_32, rcread_32;
  //what has been input at stdin
  unsigned char charInput;
  //buffer 
  unsigned char buf[255];
  //buffer for image
  unsigned char imageBuf[1000000];
  
  //open the device files 
  fdwrite = open("/dev/xillybus_write_8", O_WRONLY);
  fdread  = open("/dev/xillybus_read_8", O_RDONLY);
  fdwrite_32 = open("/dev/xillybus_write_32", O_WRONLY);
  fdread_32  = open("/dev/xillybus_read_32", O_RDONLY);
  int imageFileDesc = open("image", O_WRONLY | O_APPEND| O_CREAT,S_IRUSR|S_IWUSR|S_IXUSR);
  int commandFileDesc = open("command.txt", O_WRONLY | O_APPEND| O_CREAT,S_IRUSR|S_IWUSR|S_IXUSR);

  //check error
  if (fdread < 0 || fdwrite < 0 || fdwrite_32 < 0 || fdread_32 < 0) {
    if (errno == ENODEV)
      fprintf(stderr, "(Maybe %s a write-only file?)\n", "write or read");

    perror("Failed to open devfile");
    exit(1);
  }
  //check error
  if (imageFileDesc < 0 || imageFileDesc < 0)
  {
      printf("Error opening file!\n");
      exit(1);
  }
 
   while (1) 
   {
    // Read from standard input = file descriptor 0
    rcwrite = read(0, buf, sizeof(buf));
    //get the char given
    charInput = buf[0];
    //check for errors
    if ((rcwrite < 0) && (errno == EINTR))
      continue;

    if (rcwrite < 0) {
      perror("allread() failed to read");
      exit(1);
    }

    if (rcwrite == 0) {
      fprintf(stderr, "Reached read EOF.\n");
      exit(0);
    }
    //write it to the write_8
    allwrite(fdwrite, buf, rcwrite);
    //read from read_8
    rcread = read(fdread, buf, sizeof(buf));
    //check errors
    if ((rcread < 0) && (errno == EINTR))
      continue;

    if (rcread < 0) {
      perror("allread() failed to read");
      exit(1);
    }

    if (rcread == 0) {
      fprintf(stderr, "Reached read EOF.\n");
      exit(0);
    }

    //write to command history - might not be necessary
    allwrite(commandFileDesc, buf, rcread);
    //if it was 'c' read from read_32
    if(charInput == 'c')
    {
      //while there is data write the data to the image file
      while((rcread_32 = read(fdread_32, imageBuf, sizeof(imageBuf))) > 0)
      {
        allwrite(imageFileDesc, imageBuf, rcread_32);
      }
         //check if there was an interrupt, just continue
         if ((rcread_32 < 0) && (errno == EINTR))
          continue;
      
    }
    
    
  }
  
}

//writes to the file descriptor given the 
//string and its length
void allwrite(int fd, unsigned char *buf, int len) {
  int sent = 0;
  int rc;

  while (sent < len) {
    rc = write(fd, buf + sent, len - sent);

    if ((rc < 0) && (errno == EINTR))
      continue;

    if (rc < 0) {
      perror("allwrite() failed to write");
      exit(1);
    }

    if (rc == 0) {
      fprintf(stderr, "Reached write EOF (?!)\n");
      exit(1);
    }

    sent += rc;
  }
}