#!/bin/sh
vsim -c -do "do runtb.do ; quit"
